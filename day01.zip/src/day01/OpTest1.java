package day01;

// ���������

public class OpTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num1 = 10;
		int num2 = 3;
		int sum, sub, mul, re;
		float div;
		
		sum = num1 + num2;
		sub = num1 - num2;
		mul = num1 * num2;
		div =(float)num1 / num2; 
		// int/int => int  10/3 => 3 => double div => 3.0 
		// 3.3333  int/int(x) =>
		// int div => 3  double div => ?
		re = num1 % num2; // 10%3 => 1
		
		System.out.println(sum);
		System.out.println(sub);
		System.out.println(mul);
		System.out.println(div);
		System.out.println(re);
	}

}
