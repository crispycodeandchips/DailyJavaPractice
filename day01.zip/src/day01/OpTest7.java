package day01;

public class OpTest7 {
	
	public static void main(String[] args) {
		
		int num = 10;
		num += 2; // num=num+2; 
		System.out.println(num); // 12
		num -=1; // num=num-1;
		System.out.println(num); // 11
		num*=2; // num=num*2
		System.out.println(num); // 22
		num/=2; // num=num/2
		System.out.println(num); // 11
		num&=2; // num=num%2;
		System.out.println(num); // 1
		
		int num1 = 2;
		int num2 = 5;
		int num3 = 4;
		
		num1*= num2 + num3; // num1 = num1 * (num2 + num3) => 18
		System.out.println(num1);
	}

	
	
}
