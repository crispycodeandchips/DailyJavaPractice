package day01;

/*
 * ���� ������ 
 * -a
 *  
*/
public class OpTest8 {

	public static void main(String[] args) {
		
		int num = 10;
		System.out.println(num); // 10
		++num ; // num = num + 1
		System.out.println(num); //11
	      ++num;
	      System.out.println(num); // 12
	      --num; //num = num - 1
	      System.out.println(num); // 11
	      --num;
	      System.out.println(num); // 10
	}
}
