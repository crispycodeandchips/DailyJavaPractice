package day01;

public class OpTest9 {
	public static void main(String[] args) {
		
		//���׿�����
		// ++a: ����  a++: ����
		
		int x = 10;
		int y = ++x;
		/*
		 * ++x=> x=x+1
		 *
		 * y=++x;
		 * x=x+1;
		 * y=x;
		 * 
		*/
		
		System.out.println(x);
		System.out.println(y);
		
		x = 10;
		y = x++;
		/*
		 * y=x;
		 * x=x+1
		 * 
		*/
		
		System.out.println(x);
		System.out.println(y);
		
		x=10;
		y=--x;
		System.out.println(x);
		System.out.println(y);
		
		x=10;
		y=x--;
		System.out.println(x);
		System.out.println(y);
	}

}
