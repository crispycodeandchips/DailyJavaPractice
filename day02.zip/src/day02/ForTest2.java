package day02;

public class ForTest2 {
	
	public static void main(String[] args) {
		
	
//		for(int i=1; i<6; i++) 
//			System.out.print(i +"\t");
//		
//		System.out.println("");
//		
//		for(int j=5; j>0; j--)
//			System.out.println(j);
		
		// 1 3 5 7 9
		for(int i=1; i<=9; i+=2) //i++ i-- i==2// i=i+2 ���մ��Կ�����
		{
			System.out.println(i+" ");
		}
		
		// 10  8  6  4   
		for(int j=10; j>=4; j-=2)
			{
			System.out.print(j+"\t");
			}
			
		System.out.println();
		for(int i=10; i>=4; i--)
		{
			if(i%2==0)
				System.out.println(i+"\t");
		}
		
	}

}
