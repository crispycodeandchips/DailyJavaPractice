package day02;

import java.util.Scanner;

public class ForTest4 {
	public static void main(String[] args) {
				
		//1.
		for(int i=4; i<=20; i++)
		{
			if(i%2==0)
				System.out.println(i);
		}
		
		System.out.println("======");
		
		//2.
		Scanner sc = new Scanner(System.in);
		int num1 = Integer.parseInt(sc.nextLine());
		System.out.println("input num1");
 		int num2 = Integer.parseInt(sc.nextLine());
 		System.out.println("input num2");
// 		System.out.print("�Է��� ��: ");
 		
 		// num1 ���� num2���� ����Ͻÿ�
 		
 		int sum=0;
 				
 		for(int i=num1; i<=num2; i++)
 		{
 			sum = sum+i; //sum+=i;
 			System.out.println(i);
 		}
 		System.out.println("���� : "+sum);
 		
	}

}
