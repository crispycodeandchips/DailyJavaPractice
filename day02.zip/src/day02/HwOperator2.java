package day02;

import java.util.Scanner;

public class HwOperator2 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("�̸��� �Է��Ͻÿ�");
		String name=sc.nextLine();
		System.out.println("input kor");
		int kor = Integer.parseInt(sc.nextLine());
		
		System.out.println("input eng");
		int eng = Integer.parseInt(sc.nextLine());
		System.out.println("int math");
		int math = Integer.parseInt(sc.nextLine());
		
		int tot = kor+eng+math;
		float avg=tot/3.0f; // tot/3 => 100/3 => 33 => 33.0
		// float avg=(float) tot/3;
		
		String result=""; // int num=0; �� ����. ���� �ʱⰪ ������ ��.
		// String s = new String();   String s="";
		if(avg>=60)
			result="�հ�";
		else
			result="���հ�";
		
		System.out.println("name : "+name);
		System.out.println("kor : "+kor);
		System.out.println("eng : "+eng);
		System.out.println("math : "+math);
		System.out.println("tot : "+tot);
		System.out.printf("avg:%.2f\n",avg);
		
		System.out.println("���:"+result);
	}
}
