package day02;

import java.util.Scanner;

public class HwOperatorTest {
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		System.out.println("input num1");
		int num1 = Integer.parseInt(sc.nextLine());
		System.out.println("input num2");
		int num2= Integer.parseInt(sc.nextLine());
	
		System.out.println("input num3");
		int num3 = Integer.parseInt(sc.nextLine());
		// Ÿ�� ���� =  (����)? ��: ����;
		
		int max = (num1 > num2)? num1 : num2;
		max = (max > num3)? max : num3;
		
		int min = (num1 < num2)? num1 : num2;
		min = (min < num3)? min : num3;
		
		System.out.println("�ִ밪 : "+max);
		System.out.println("�ּҰ� : "+min);
}
}
