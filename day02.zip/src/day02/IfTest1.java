package day02;

public class IfTest1 {

	public static void main(String[] args) {
		
		int kor=80;
		
		if(kor>=90) {
			
			System.out.println("��");
			
		}else if (kor>=80)
			System.out.println("��");
		else if (kor>=70)
			System.out.println("��");
		else if (kor>=60)
			System.out.println("��");
		else
			System.out.println("��");
		
		
	}
}
