package day02;

import java.util.Scanner;

public class IfTest2 {
	public static void main(String[] args) {
		
		//kor eng�� �Է¹����ÿ�.
		
		Scanner sc = new Scanner(System.in);
		System.out.println("input kor");
		int kor = Integer.parseInt(sc.nextLine());
		System.out.println("input eng");
		int eng = Integer.parseInt(sc.nextLine());
		
		if(kor>=90)
		{
			if(eng>=90)
				System.out.println("kor 90�̻� eng 90�̻�");
		else
			System.out.println("kor 90�̻��̰� eng 90�̸�");
		}else {
			if(eng>=90)
				System.out.println("kor 90�̸� eng 90�̻�");
			else
				System.out.println("kor 90�̸� eng 90�̸�");
		}
	}
}
