package day02;

import java.util.Scanner;

public class IfTest3 {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("������ �Է��ϼ���");
		int kor = Integer.parseInt(sc.nextLine());
		int eng = Integer.parseInt(sc.nextLine());
		
		if (kor >= 90) //4���� kor eng math => 8  kor eng math mu => ���� hint ��������
		
			
			{
			if (eng >= 90)
			System.out.println("very good");
			else 
			System.out.println("good");
		
			} else {
				if (eng >= 90)
					System.out.println("good");
				else
					System.out.println("bad");
		}
	
	}

}
