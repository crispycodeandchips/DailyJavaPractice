package day02;

public class SwitchTest2 {
	public static void main(String[] args) {
	
//		int num = 1;
//		
//		switch(num)
//		{
//		case 1:
//			System.out.println("1�Դϴ�");
//		case 2:
//			System.out.println("2�Դϴ�");
//		case 3:
//			System.out.println("3�Դϴ�");
//		default :
//			System.out.println("������ ���");
//		}
		
		
//		String data="a";
//		switch(data)
//		{
//		case "a":
//			System.out.println("a");
//			break;
//		case "b":
//			System.out.println("b");
//			break;
//		case "c":
//			System.out.println("c");
//			break;
//		default:
//				System.out.println("������ ���");
//			
//		} // end switch
//	} // end main
//} // end class
		
		String data="h";
		switch(data)
		{
		case "h":
			System.out.print("h");
			
		case "e":
			System.out.print("e");
			
		case "ll":
			System.out.print("ll");
		case "o":
		System.out.println("o");
		break;
		default:
			System.out.println("�Է��� �߸��Ǿ����ϴ�.");
		}
 }
}