package day02;

public class WhileTest2 {
	public static void main(String[] args) {
		
//		System.out.println("while�� �����ϱ�");
//		int i=10;
//		while(1<10;) {
//			System.out.println(i);
//			i++;
//		}
		
//		int i=10;
//		do {
//			System.out.println(i);
//			i++;
//		} while(i<10);
		
		
		// 1 2 3 4 5
		//do.. while ��
		
		int i=1;
		do {
			System.out.println(i);
			i++;
			
		}while(i < 6);
	}

}
