package day02;

public class for2Test1 {
	
	public static void main(String[] args) {
		
//		for (int i=1; i<=9; i++) // ������ �����̴� �ֵ��� �ٱ��ʿ� ���
//		{
//			for(int j=2; j<=5; j++) // ���� �����̴� �ֵ��� ���ʿ� ���
//			{
//				System.out.print(j+"*"+i+"="+(j*i)+"\t");
//			}
//			System.out.println();
//		}
		
		/*
		 * 1 2 3 4 5
		 * 1 2 3 4 5
		 * 1 2 3 4 5 
		*/
		
//		for(int i=1; i<=3; i++)
//		{
//			for(int j=1; j<=5; j++)
//			{
//				System.out.println(j+" ");
//			}
//			System.out.println();
//		}
		
		
		/*
		 * 1 1 1 1
		 * 2 2 2 2
		 * 3 3 3 3
		*/	
		
//		for (int i=1; i<=3; i++)
//		{
//			for(int j=1; j<=4; j++)
//			{
//				System.out.print(i+"\t");
//			}
//			System.out.println();
//		}
		
		 for(int i=1; i<=3; i++)
		 {
		 	for(int j=1; j<=4; j++)
		 		{
		 		System.out.print("*\t");
		 		}
		 	System.out.println();
		 	}
		
	}

}
