package day04;

public class ArrayTest {
	
	public static void main(String[] args) {
		
		int[] arr;
			arr = new int[3];
		int[] arr2 = new int[3]; // int a = 10
		
		for(int i=0; i<3; i++)
			System.out.print(arr[i]);
		
		System.out.println("========");
		
		for(int i=0; i<3; i++)
			System.out.println(arr2[i]);
		
	} 

}
