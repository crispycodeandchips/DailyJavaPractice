package day04;

public class SwitchTest {
	public static void main(String[] args) {

//      int i=1;
//      while(i<=10)
//      {
//      	System.out.println(i);
//      	i++;
//      }
//      System.out.println("ddd"+i);
//		
		for (int i = 1; i <= 10; i++)
		{
			System.out.println(i);
		System.out.println("end " + i);
		} // for
	}

}
