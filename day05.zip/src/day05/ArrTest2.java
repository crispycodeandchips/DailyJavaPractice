package day05;

public class ArrTest2 {
public static void main(String[] args) {
	
	int[] a;
	a = new int[3];
	
	int[] arr = new int[3];
	arr[0]=10;
	arr[1]=20;
	arr[2]=30;
	
	int[] arr2 = {10,20,30};
	
	//������ ����
	//int[] b;
	//b= {10,20,30};
	
	//int[] age new int[] {10,20,30};�Լ�... �޼���...
	
}
	}
