package day06;

public class Arr {
	// �迭���
	public void prt(String[] b)
	{
		
		for(String index:b)
			System.out.println(index);
	}

}
