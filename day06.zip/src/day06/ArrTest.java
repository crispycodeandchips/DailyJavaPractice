package day06;

public class ArrTest {
	
	public static void main(String[] args) {
		
		Arr ins = new Arr();
		//String[] arr = new String[5];
		
//		String[] arr = {"hong", "kim", "lee", "park", "yoo"};
//		arr[0] = "hong";
//		arr[1] = "kim";
//		arr[2] = "lee";
//		arr[3] = "park";
//		arr[4] = "yoo";
		
//		String[] arr = new String[] {"hong", "kim", "lee", "park", "yoo"};
//		String[] arr2 = {"hong", "lee", "park"};
//		String[] arr3 = new String[3];
//		arr3[0] = "hong";
//		arr3[1] = "lee";
//		arr3[2] = "park";
//		
//		^^^ �迭�� �ʱ�ȭ�ϴ� 3���� ���.
		
		ins.prt(new String[]{"a","b","c"});
		
		
	}

}
